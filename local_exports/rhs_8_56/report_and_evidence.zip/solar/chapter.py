"""Produce the chapter and assert the principal comparisons from interval evidence."""
from pathlib import Path
import numpy as np
import pandas as pd
from replay import OUT
pv=pd.read_csv(OUT/'pv_predictions.csv',parse_dates=['end','origin','last_input_published'])
assert (pv.last_input_published<pv.origin).all()
score=pd.read_csv(OUT/'pv_metrics.csv')
routine=score.query("cohort=='routine' and daylight")
stress=score.query("cohort=='low_PV_stress' and daylight")
assert routine.n.eq(96).all() and stress.n.eq(24).all()
assert (pd.read_csv(OUT/'case_replays.csv').eval('abs(calculated_rhs-published_rhs)')<5e-7).all()
def table(df):
    return df.pivot(index='method',columns='lead_days',values='mae').rename(columns={10:'10 days',21:'21 days',42:'42 days'}).to_markdown(floatfmt='.1f')
f=pd.read_csv(OUT/'full_scores.csv')
b=pd.read_csv(OUT/'full_forecast.csv')
b['date']=pd.to_datetime(b.end).dt.normalize()
z=pd.read_csv(OUT/'rhs_pv_substitution.csv')
z['slot']=pd.to_datetime(z.slot)
bridge=z.drop_duplicates('end').query("active_branch=='metro'").bridge_error.abs().mean()
p=pd.read_csv(OUT/'case_replays.csv')
h=pd.read_csv(OUT/'issued_coverage.csv')
assert (pd.to_datetime(h['last'])-pd.to_datetime(h.origin)).eq(pd.Timedelta(days=7,hours=4)).all()
geo=routine[routine.method.str.startswith('geometry')].sort_values('lead_days')
err=stress.query("lead_days==42 and method=='geometry-adjusted 14-day median'").iloc[0]
cover='; '.join(f"{r.lead_days} days {r.coverage:.0%} ({int(r.band_n)}/{int(r.n)} slots eligible)" if r.band_n else f"{r.lead_days} days insufficient history" for r in geo.itertuples())
report=f"""### When SA rooftop generation changes the dispatch RHS

The South Australian MAXG equation V::S_NIL_MAXG_1 (dispatch version 1, effective 8 December 2025) subtracts the larger of a statewide maximum-generation term and a gated metropolitan term from its remaining line-flow, load and trader contributions. With fewer than two Black Range capacitors in service, the expression selects the 10,000 MW bypass. The gated term is (1.2 × metropolitan maximum + 0.36 × total distributed PV) multiplied by the daytime and metro-generation status flags. The statewide maximum includes individual or grouped trader injections, analogue values and Murraylink initial MW. This is a South Australian worked example. It supplies no evidence of direct rooftop exposure for a QNI or VNI equation.

On the ordinary PV branch the shared expression is entered regional solar MW × (1 + 65/2,228) + SAPN-controlled PV MW. The effective formulation supplies those two constants. The override uses the positive product of the period flag and the HDRESS analogue when that analogue is below 10,000. If that product is nonpositive the ordinary branch applies. Keep the entered estimate, separately measured controlled PV, override and period flag distinct. When regional demand already reflects PV, change only the PV deviation from the embedded assumption in any net-load scenario. Preserve the explicit solar term in the MAXG expression.

Independent calculation matched all 72 official five-minute nonintervention RHS results within 0.00000050 MW. These are three two-hour windows on 1, 15 and 19 February 2026, originally selected for another study. In 48 midday intervals the metropolitan term controlled the result. A 1 MW increase in entered PV lowered the RHS by 0.37050 MW, while 1 MW more controlled PV lowered it by 0.36 MW. A joint increase of 100 and 10 MW respectively lowered the RHS by 40.65 MW. In the other 24 intervals the statewide branch controlled and these perturbations had zero effect. For a 5 MW error allowance on the sensitive branch, the entered solar forecast alone must be within 13.5 MW, holding the other terms fixed. No historical sample activated the override. Forcing a 500 MW override on midday cases increased the calculated RHS by 453.8 MW on average. That is a branch scenario.

### What can be forecast at the three leads

All {len(h)} sampled origin-matched public rooftop forecasts ended seven days and four hours after the origin. None covered a 10-, 21- or 42-day target. We estimated regional PV from original SA measurement reports created and timestamped in the archive before each midnight forecast origin. The first method repeats the latest available observation for that delivery clock. The second takes the previous 14 observations' median. The third adjusts the historical readings for the seasonal change in solar elevation before taking their median. It uses flat horizontal geometry at Adelaide, approximate mid-interval sun position and a median fallback near the horizon. Cloud fields, panel orientation and installed-capacity changes remain unmodelled.

The routine set uses all 48 half-hours on each of four preassigned Sundays (1, 8, 15 and 22 February). The table reports mean absolute error in MW across the 96 interval endings from 07:00 to 18:30 fixed NEM time at each lead. Sunrise, evening and night comparisons, bias and tail errors are also retained. The target is AEMO's contemporaneously published regional PV estimate. A site-level allocation is unnecessary for this regional input. Controlled rooftop generation is a separate population and would need independent calibration.

{table(routine)}

A retrospective stress day, 28 February, had the lowest daily regional PV total of the month. The elevation-adjusted method's 42-day error rose to {err.mae:.1f} MW across its 24 daylight-clock intervals. Selection used the realised stress event only for evaluation. Seven native-clock historical errors produced symmetric bands separately for each method and lead. Each calibration prediction used the same horizon, only information available at its own origin, and calibration outcomes present before the evaluated forecast. Missing seven qualifying residuals suppresses the band. Routine coverage for the elevation-adjusted method was {cover}. A small number of adjacent calibration days does not establish a reliable interval for another weather regime.

### Conditional input error and complete-equation forecasts

The regional public estimate and the dispatch-entered solar value are distinct. Substituting even the *target-time* regional half-hour measurement for the entered five-minute value introduced {bridge:.2f} MW average absolute RHS error on the 48 sensitive intervals, keeping every other input observed. The independent regional value differed from entered solar by 25.19 MW on those intervals. The public data alone do not identify how much is timing, interval aggregation or source definition. For forecast PV injected into otherwise observed cases, elevation-adjusted native RHS error was 20.58, 17.99 and 10.02 MW at 10, 21 and 42 days over all 72 cases. These are conditional contributions, not full RHS forecast errors. Each predicted half-hour PV is held across its six intervals and passes through the complete nonlinear formula.

For a full forward benchmark, select the same delivery-clock five-minute case two calendar days before forecast issue. Its trading-day release cycle and original member timestamp both precede the cutoff. Carry that joint historical equipment, unit, transfer, override and load state through the dispatch expression and replace only the regional PV input with the respective lead-time projection. The carry baseline repeats that prior case's published RHS. The issue-time calculation assumes this equation remains invoked. It does not predict economic binding. The table scores half-hour means only when all six native predictions and labels exist, on {int(f.n.min())} complete half-hours per method and lead across the three target windows. The saved file also contains each native predicted and actual branch.

{table(f)}

The controlled-electrical-share variant also changes SAPN-controlled PV in proportion to its share of regional entered PV in the pre-origin same-clock case. It holds the earlier value when that denominator is 50 MW or less. Against holding controlled PV fixed, the joint update changed MAE by about −1.1, −0.4 and +0.5 MW at 10, 21 and 42 days. All projected branches matched the delivery branch in these windows, and none of the 72 delivery intervals had a nonzero economic marginal value for this equation. Operating transitions and SA binding alerts therefore remain untested.

Use both the joint prior-state baseline and PV-adjusted scenarios. Region-wide solar accuracy and RHS usefulness can rank estimators differently because the branch gates, transfer, metro generation and bypass can dominate the error. Switch the simulated plant and topology path jointly with the renewable path when better dated schedules exist. The QNI/VNI study should use its own scoped terms and cannot inherit these coefficients.

[AEMO dispatch formulation operations](https://aemo.com.au/-/media/files/stakeholder_consultation/consultations/nem-consultations/2023/constraints-implementation-guidelines/final-constraint-implementation-guidelines-v3.pdf) · [Original regional PV measurements](https://www.nemweb.com.au/Reports/ARCHIVE/ROOFTOP_PV/ACTUAL/) · [Issued rooftop forecasts](https://www.nemweb.com.au/Reports/ARCHIVE/ROOFTOP_PV/FORECAST/) · [Public NEMDE file publication cycle](https://www.aemo.com.au/-/media/files/electricity/nem/it-systems-and-change/nemde-queue/nemde_queue_users_guide.pdf) · [Five-minute inputs and replay](case_replays.csv) · [Regional scores and band eligibility](pv_metrics.csv) · [Forecast horizon audit](issued_coverage.csv) · [Full five-minute forecasts](full_forecast.csv) · [Full half-hour scores](full_scores.csv) · [Source hashes](source_hashes.json)
"""
(OUT/'report.md').write_text(report,encoding='utf8')

